﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace CSh2Lesson_7
{
    public partial class MainWindow : Window
    {
        SqlConnection connection;
        SqlDataAdapter adapter;
        DataTable dt;
        string sValue = "";
        public MainWindow()
        {
            InitializeComponent();
            #region Добавление значений в Список департаментов
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
            SqlCommand command = new SqlCommand(
            "SELECT NAMEDEP FROM Department", connection);
            dt = new DataTable();
            adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            adapter.Fill(dt);
            WorkerComBox.DataContext =dt.DefaultView;
            #endregion
         
        }
        private void WorkerComBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            #region Запрос на вывод только рабочих из департамента(Перевод выделенного CB из DataRowView в Текст)
            DataRowView oDataRowView = WorkerComBox.SelectedItem as DataRowView;// DataRowView oDataRowView = (DataRowView)WorkerComBox.SelectedItem;

            if (oDataRowView != null)
            {
                sValue = oDataRowView.Row["NAMEDep"] as string;
            }
            #endregion

            Window_Loaded(sender, e);
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            #region Подключение и выбор параметров базы
            var connectionStringBuilder = new SqlConnectionStringBuilder
            {
                DataSource = @"(localdb)\MSSQLLocalDB",
                InitialCatalog = "Less7"
            };
            connection = new SqlConnection(connectionStringBuilder.ConnectionString);
            adapter = new SqlDataAdapter();
            
            SqlCommand command = new SqlCommand("SELECT ID, FIO, DepId FROM Employee WHERE DepId='"+sValue+"'", connection);
            adapter.SelectCommand = command;
            #endregion
            #region Вставка нововго значения в список и БД
            command = new SqlCommand(@"INSERT INTO Employee (FIO, DepId) 
                          VALUES (@FIO, @DepId); SET @ID = @@IDENTITY;",
                         connection);
            command.Parameters.Add("@FIO", SqlDbType.NVarChar, -1, "FIO");
            command.Parameters.Add("@DepId", SqlDbType.NVarChar, -1, "DepId");
            SqlParameter param = command.Parameters.Add("@ID", SqlDbType.Int, 0, "ID");
            param.Direction = ParameterDirection.Output;
            adapter.InsertCommand = command;
            #endregion
            #region Редактирование значения списка и БД
            command = new SqlCommand("UPDATE Employee SET FIO = @FIO, DepId = @DepId WHERE ID = @ID", connection);
            command.Parameters.Add("@FIO", SqlDbType.NVarChar, -1, "FIO");
            command.Parameters.Add("@DepId", SqlDbType.NVarChar, -1, "DepId");
            param = command.Parameters.Add("@ID", SqlDbType.Int, 0, "ID");
            param.SourceVersion = DataRowVersion.Original;
            adapter.UpdateCommand = command;
            #endregion
            #region Удаление значения из списка и БД
            command = new SqlCommand("DELETE FROM Employee WHERE ID = @ID", connection);
            param = command.Parameters.Add("@ID", SqlDbType.Int, 0, "ID");
            param.SourceVersion = DataRowVersion.Original;
            adapter.DeleteCommand = command;
            dt = new DataTable();
            adapter.Fill(dt);
            WorkerList.DataContext = dt.DefaultView;
            #endregion
        }

        /// <summary>
        /// Добавление новой записи
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            DataRow newRow = dt.NewRow();
            EditEmp editWindow = new EditEmp(newRow);
            editWindow.ShowDialog();
            if (editWindow.DialogResult.Value)
            {
                dt.Rows.Add(editWindow.resultRow);
                adapter.Update(dt);
            }
        }
        /// <summary>
        /// Редактирование существующей записи
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            DataRowView newRow = (DataRowView)WorkerList.SelectedItem;
            newRow.BeginEdit();
            EditEmp editWindow = new EditEmp(newRow.Row);
            editWindow.ShowDialog();
            if (editWindow.DialogResult.HasValue && editWindow.DialogResult.Value)
            {
                newRow.EndEdit();
                adapter.Update(dt);
            }
            else
            {
                newRow.CancelEdit();
            }
        }
        /// <summary>
        ///Удаление существующей записи
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            DataRowView newRow = (DataRowView)WorkerList.SelectedItem;
            if (newRow!=null)
            {
                newRow.Row.Delete();
                adapter.Update(dt);
            }
            
        }

       
    }
}