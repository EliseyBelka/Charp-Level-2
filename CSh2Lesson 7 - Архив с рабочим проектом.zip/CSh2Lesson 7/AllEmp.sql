﻿SELECT
*
FROM Employee