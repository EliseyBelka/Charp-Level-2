﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FillDB
{
    public class DUser
    {
        public string NAMEDep;
    }
    public class EUser
    {
        public string FIO;
        public string DepId;
    }
}
