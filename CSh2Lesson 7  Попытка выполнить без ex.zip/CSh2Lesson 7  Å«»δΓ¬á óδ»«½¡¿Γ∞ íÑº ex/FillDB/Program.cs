﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FillDB
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString =
                @"  Data Source=(localdb)\MSSQLLocalDB;
                    Initial Catalog=Less7;
                    Integrated Security=True;
                    Pooling=False";
            #region Write Department
            Console.WriteLine("Будет выполнено заполнение таблицы department <Press Enter>");
            Console.ReadLine();
            try
            {
                for (int i = 1; i < 26; i++)
                {
                    var Duser = new DUser
                    {
                        NAMEDep = $"Dep{i}"
                    };
                    var sql = String.Format("INSERT INTO Department (NAMEDep) " +
                                            "VALUES (N'{0}')",
                                            Duser.NAMEDep);
                    Console.WriteLine(sql); // Показ выполннение SQL
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand(sql, connection);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            #endregion
            Console.WriteLine("Будет выведен список департаментов <Press Enter>");
            Console.ReadLine();
            #region Read Department
            string[] mas = new string[1000];
            int j = 0;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var sql = @" SELECT * FROM Department";
                    SqlCommand command = new SqlCommand(sql, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        //сохраняем названия в массив для случайного заполнения департамента сотрудника
                        j++;
                        mas[j] = (reader["NAMEDep"]).ToString();
                        //
                        Console.WriteLine(reader["NAMEDep"]);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion
            Console.WriteLine("Будет выполнено заполнение таблицы Employee <Press Enter>");
            Console.ReadLine();
            #region Write Employee
            try
            {
                var random = new Random();
                for (int i = 1; i < 501; i++)
                {
                    var Euser = new EUser
                    {
                        FIO = $"ЧОС-{i}",
                        DepId = $"{mas[random.Next(1, j+1)]}"
                    };
                    var sql = String.Format("INSERT INTO Employee (FIO, DepId) " +
                                            "VALUES (N'{0}','{1}')",
                                            Euser.FIO, Euser.DepId);

                    Console.WriteLine(sql); // Показ выполннение SQL
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand(sql, connection);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            #endregion
            Console.WriteLine("Будет выведен список сотрудников <Press Enter>");
            Console.ReadLine();
            #region Read Employee
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    var sql = @" SELECT * FROM Employee";
                    SqlCommand command = new SqlCommand(sql, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["FIO"]}  |  {reader["DepId"]} ");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion
            Console.WriteLine("Заполнение прошло успешно <Press Enter>");
            Console.ReadLine();
        }
    }
}
