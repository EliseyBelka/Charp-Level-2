﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using System.Configuration;//для доступа к конфиг //добавлена такая же dll !!!
using System.Data;//++DataTable++

namespace CSh2Lesson_7
{
    public partial class MainWindow : Window
    {//подключеие к базе данных. Конфигурация описанна в App.config
        static string connectionString =
        ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;   //DefaultConnection названи взято из App.config
        static SqlConnection connection = new SqlConnection(connectionString); //предоставляет подключение к базе данных из конфига
        static SqlDataAdapter adapter = new SqlDataAdapter();          //предоствляет возможность изменять БД        

        public MainWindow()
        {
            InitializeComponent();
            #region Загрузка значений Dep в CB из БД
            SqlCommand command = new SqlCommand(                    //предоставляет возможно пользовать командами направляемые в БД
            "SELECT NAMEDEP FROM Department",                   //пишем какое поле взять NAMEDEP и из какой таблицы Depatment БД описанной в App.config - Less7
            connection);
            DataTable DepFillDT = new DataTable();
            adapter.SelectCommand = command; //свзяываем адаптер и команд ("разрешение на использование команд для /\ ДБ")
            adapter.Fill(DepFillDT); //заполнить дата тейбл данными 
            WorkerComBox.DataContext = DepFillDT.DefaultView; //вывести данные в дата КомБокс
            #endregion
            #region Удаление значения из Департамена и Всех Сотрудников этого Департамента.
            command = new SqlCommand("DELETE FROM Department WHERE NAMEDEP = @NAMEDEP", connection);
            SqlParameter parameter = command.Parameters.Add("@NAMEDEP", SqlDbType.NVarChar, 0, "NAMEDEP");
            adapter.DeleteCommand = command;
            Delete.Click += (sender, args) =>
            {
                DataRowView rowView = (DataRowView)WorkerComBox.SelectedItem;
              
                connection.Open();
                string sValue = "";
                if (rowView != null)
                {
                    sValue = rowView.Row["NAMEDep"] as string;
                command = new SqlCommand($@"DELETE FROM EMPLOYEE WHERE DEPID=" + "'" + sValue + "'", connection);
                command.ExecuteNonQuery();
                rowView.Row.Delete();
                adapter.Update(DepFillDT);
                }
                connection.Close();
            };
            #endregion
        }
        /// <summary>
        /// Изменение выделенного значения в списке департаментов.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WorkerComBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            #region Запрос на вывод только рабочих из департамента(Перевод выделенного CB из DataRowView в Текст)
            DataRowView oDataRowView = WorkerComBox.SelectedItem as DataRowView;// DataRowView oDataRowView = (DataRowView)WorkerComBox.SelectedItem;
            string sValue = "";
            if (oDataRowView != null)
            {
                sValue = oDataRowView.Row["NAMEDep"] as string;
            }
            #endregion
            #region Загрузка значений Emp в LB из БД
            SqlCommand command = new SqlCommand(
                "SELECT * FROM EMPLOYEE WHERE DEPID ="+"'"+sValue+"'",                 
                connection);
            adapter.SelectCommand = command;                        
            DataTable EmpFillDT = new DataTable();                  
            adapter.Fill(EmpFillDT);         
            WorkerList.DataContext = EmpFillDT.DefaultView;         
            #endregion
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            //DataRowView newRow = (DataRowView)WorkerList.SelectedItem;
            //newRow.BeginEdit();
            //DataTable EmpEdit = new DataTable();
            //EditEmp editEmp = new EditEmp(newRow.Row);
            //editEmp.ShowDialog();

            //if (editEmp.DialogResult.HasValue && editEmp.DialogResult.Value)
            //{
            //    newRow.EndEdit();
            //    adapter.Update(EmpEdit);
            //}
            //else
            //{
            //    newRow.CancelEdit();
            //}
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
//            var connectionStringBuilder = new SqlConnectionStringBuilder
//            {
//                DataSource = @"(localdb)\MSSQLLocalDB",
//                InitialCatalog = "Less7"
//            };

//            connection = new SqlConnection(connectionStringBuilder.ConnectionString);
//            adapter = new SqlDataAdapter();

//            SqlCommand command =
//                new SqlCommand("SELECT ID, DepId FROM Employee",
//                connection);
//            adapter.SelectCommand = command;
//            command = new SqlCommand(@"UPDATE Employee SET FIO = @FIO,
//DepId = @DepId, WHERE ID = @ID", connection);
//            SqlParameter param = command.Parameters.Add("@ID", SqlDbType.Int, 0, "ID");
//            command.Parameters.Add("@FIO", SqlDbType.NVarChar, -1, "FIO");
//            command.Parameters.Add("@DepId", SqlDbType.NVarChar, -1, "DepId");
//            param = command.Parameters.Add("@ID", SqlDbType.Int, 0, "ID");

//            param.SourceVersion = DataRowVersion.Original;

//            adapter.UpdateCommand = command;
        }
    }
}
