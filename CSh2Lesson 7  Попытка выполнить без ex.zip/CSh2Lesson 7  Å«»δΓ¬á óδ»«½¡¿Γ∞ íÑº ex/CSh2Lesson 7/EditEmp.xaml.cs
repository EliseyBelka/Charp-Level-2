﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CSh2Lesson_7
{
    /// <summary>
    /// Логика взаимодействия для EditEmp.xaml
    /// </summary>
    public partial class EditEmp : Window
    {
             public DataRow resultRow { get; set; }
        public EditEmp(DataRow dataRow)
        {
            InitializeComponent();
            resultRow = dataRow;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TBE.Text = resultRow["FIO"].ToString();
            TBEID.Text = resultRow["depId"].ToString();
        }
  
        private void saveButton(object sender, RoutedEventArgs e)
        {
            resultRow["FIO"] = TBE.Text;
            resultRow["depId"] = TBEID.Text;
            this.DialogResult = true;
        }

        private void cancelButton(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
