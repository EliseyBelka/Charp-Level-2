﻿using System;
using System.Drawing;
using MyGame;

namespace Level2Les1
{
    class Star : BaseObject
    {
        public Star(Point pos, Point dir, Size size) : base(pos, dir, size)
        {
        }
    }
}
