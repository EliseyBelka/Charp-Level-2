﻿//   Создать WPF-приложение для ведения списка сотрудников компании.
//  1. Создать сущности Employee и Department и заполнить списки сущностей начальными данными.
//  2. Для списка сотрудников и списка департаментов предусмотреть визуализацию (отображение). 
//    Это можно сделать, например, с использованием ComboBox или ListView.
//  3. Предусмотреть возможность редактирования сотрудников и департаментов. Должна быть возможность изменить департамент у сотрудника.
//    Список департаментов для выбора можно выводить в ComboBox.
//  4. Предусмотреть возможность создания новых сотрудников и департаментов.Реализовать данную возможность на форме редактирования.
//   АВТОР исполнения Белканов Алексей
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
namespace C2Lesson5
{
    /// <summary>
    /// Описание класс рабочий: 1 сотрудник(Employee), 2 департамент(Department)
    /// </summary>
    public class cWorkers
    {
        public string Employee;
        public string Department;
        public cWorkers(string employee, string department)
        {
            Employee = employee;
            Department = department;
        }
    }
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int СHoice;//потребовалась для отработки запросов к пользователю по редактируемому элементу.
        /// <summary>
        /// Метод: заполнение ListView данными о сотрудниках -=TASK2=-
        /// </summary>
        /// <param name="WorkerCount">Количество записей в вьюшке</param>
        void LWFill(int WorkerCount)
        {
            for (int i = 0; i < WorkerCount; i++)
            {
                ListView1.Items.Add($"{workers[i].Employee,-10}{workers[i].Department,10}");
            }
        }
        List<cWorkers> workers = new List<cWorkers> ();
        public MainWindow()
        {
            InitializeComponent();
            #region Заполнение списка сущнойстей начальными данными -=TASK1=-
            string[] Dep = new string[] { "Прг", "Бух", "Адм" };
            ComboBoxDep.Items.Add("Прг");
            ComboBoxDep.Items.Add("Бух");
            ComboBoxDep.Items.Add("Адм");
            Random rnd = new Random() { };
            for (int i = 0; i < 10; i++)
            {
                workers.Add(new cWorkers("ЧОС-" + i, Dep[rnd.Next(0, Dep.Length - 1)]));
            }
            #endregion

        }
        private void Window_Activated(object sender, EventArgs e)
        {
            ListView1.Items.Clear();
            LWFill(workers.Count);
        }
        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {//Случайно выбранные действия не получается убрать как WF при запуске
        }
        /// <summary>
        /// Удаление позиции из списка
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                workers.RemoveAt(ListView1.SelectedIndex);
                ListView1.Items.Clear();
                LWFill(workers.Count);
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Не выбран элемент для удаления");
            }
        }
        /// <summary>
        /// Отображение инструментов для добавления нового сотрудника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TBD.Visibility = TBE.Visibility = AddNew.Visibility = Visibility.Visible;
                Add.IsEnabled = Edit.IsEnabled = Delete.IsEnabled = !true;
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Не выбрано значение");
            }
        }
        /// <summary>
        /// Добавление нового сотрудника в список, -=TASK4=-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddNew_Click(object sender, RoutedEventArgs e)
        {
            int chec=0;
            TBD.Visibility = TBE.Visibility = AddNew.Visibility = Visibility.Hidden;
            if (TBE.Text != "" & TBD.Text != "") workers.Add(new cWorkers(TBE.Text, TBD.Text));
            ListView1.Items.Clear();
            LWFill(workers.Count);
            for (int i = 0; i < workers.Count-1; i++)
            {
                if (workers[i].Department == TBD.Text) chec++;
            }
            if (chec == 0)
                ComboBoxDep.Items.Add(workers[workers.Count - 1].Department);
            TBD.Text = TBE.Text = "";
            Add.IsEnabled = Edit.IsEnabled = Delete.IsEnabled = true;
        }
        /// <summary>
        ///  Отображение инструментов для редактирвоания сотрудника/департамента
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ListView1.SelectedIndex != -1)
                {
                    Add.IsEnabled = Edit.IsEnabled = Delete.IsEnabled = !true;
                    ComboBoxDep.Visibility = TBE.Visibility = AddEdit.Visibility = Visibility.Visible;
                    TBE.Text = workers[ListView1.SelectedIndex].Employee;
                    ComboBoxDep.Text = workers[ListView1.SelectedIndex].Department;
                    СHoice = ListView1.SelectedIndex;
                } else MessageBox.Show("Не выбран элемент для изменения");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Не выбран элемент для изменения");
            }
        }
        /// <summary>
        /// Редактирование существующего сотрудника выбранного из списака -=TASK3=-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_AddEdit(object sender, RoutedEventArgs e)
        {
            ComboBoxDep.Visibility = TBE.Visibility = AddEdit.Visibility = Visibility.Hidden;
            #region Обработка события - если пользователь не ввел имя.
            if (TBE.Text == "")
            {
                System.Windows.MessageBoxResult result = MessageBox.Show("Вы хотите оставить поле Employee пустым?", "Тебуется выбор", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    if (ComboBoxDep.Text != "") workers.Add(new cWorkers(TBE.Text, ComboBoxDep.Text));
                    workers.RemoveAt(СHoice);
                }
            }
            #endregion
            #region Запрос на удаление редактируемой записи и проверка наличия одинаковых сотрудников при добавление
            if (TBE.Text != "")
            {
                System.Windows.MessageBoxResult result = MessageBox.Show("Оставить редактируемую запись?", "Тебуется выбор", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.No)
                {
                    workers.Add(new cWorkers(TBE.Text, ComboBoxDep.Text));
                    workers.RemoveAt(СHoice);
                }
                if (result == MessageBoxResult.Yes)
                {
                    if (TBE.Text != workers[СHoice].Employee | ComboBoxDep.Text !=workers[СHoice].Department)
                        workers.Add(new cWorkers(TBE.Text, ComboBoxDep.Text));
                    else
                        MessageBox.Show("Такой сотрудник ужее имеется в списке!!!");
                }
            }
            #endregion

            ListView1.Items.Clear();
            LWFill(workers.Count);
            ComboBoxDep.Text = TBE.Text = "";
            Add.IsEnabled = Edit.IsEnabled = Delete.IsEnabled = true;
        }
    }
}