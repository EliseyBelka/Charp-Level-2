﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace C2Lesson6
{
    /// <summary>
    /// Логика взаимодействия для Edit_Delegat.xaml
    /// </summary>
    public partial class Edit_Delegat : Window
    {
        static public Works works;
        public Edit_Delegat()
        {
            InitializeComponent();
            works = new Works();
            ED.DataContext = works;
            works.FillBaseOfWorks();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
