﻿using System.ComponentModel;

namespace C2Lesson6
{
    public class Depart : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string employees;
        public string Employees
        {
            get => this.employees;
            set
            {
                this.employees = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.Employees)));
            }
        }
        private string department;
        public string Department
        {
            get => this.department;
            set
            {
                this.department = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.Department)));
            }
        }
    }
}

