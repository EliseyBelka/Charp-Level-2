﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace C2Lesson6
{
    public class Depende : DependencyObject
    {
        public static readonly DependencyProperty EMPProperty;
        public static readonly DependencyProperty DEPProperty;

        static Depende()
        {
            EMPProperty = DependencyProperty.Register("Employees", typeof(string), typeof(Depende));
            DEPProperty = DependencyProperty.Register("Department", typeof(string), typeof(Depende));
        }
        public string Employees
        {
            get { return (string)GetValue(EMPProperty); }
            set { SetValue(EMPProperty, value); }
        }
        public string Department
        {
            get { return (string)GetValue(DEPProperty); }
            set { SetValue(DEPProperty, value); }
        }
    }
}
