﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace C2Lesson6
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static public Works works;
        public MainWindow()
        {
            InitializeComponent();
            works = new Works();
            MainWindow1.DataContext = works;
            works.FillBaseOfWorks(); 
        }
        private void AddNewClick(object sender, RoutedEventArgs e)
        {
            AddNewPerson wAddNewPers = new AddNewPerson {Owner = this};
            wAddNewPers.Show();
        }
        /// <summary>
        /// редактирование списка Департаментов
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EditDep_Click(object sender, RoutedEventArgs e)
        {
            Edit_Delegat wEditDep = new Edit_Delegat {Owner = this};
            wEditDep.Show();
        }
        /// <summary>
        /// Редактирование списка сотрудников
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EditListClick(object sender, RoutedEventArgs e)
        {
            EditPers wEditList = new EditPers { Owner = this };
            wEditList.Show();
        }
    }

   
}


//https://metanit.com/sharp/wpf/2.4.php