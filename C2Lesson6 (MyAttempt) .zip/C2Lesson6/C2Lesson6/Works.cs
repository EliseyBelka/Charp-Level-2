﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C2Lesson6
{
    public class Works : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public ObservableCollection<Depende> BaseOfWorks { get; set; }
  
        public void FillBaseOfWorks()
        {
            this.BaseOfWorks = new ObservableCollection<Depende>()
           {
                new  Depende(){Employees ="Чос-0",Department="Прг"},
                new  Depende(){Employees ="Чос-1",Department="Адм"},
                new  Depende(){Employees ="Чос-2",Department="Бхг"},
                new  Depende(){Employees ="Чос-3",Department="Адм"},
                new  Depende(){Employees ="Чос-4",Department="Бхг"},
            };
     
        }
    }

}
