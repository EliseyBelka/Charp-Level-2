﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ClientLess8
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        int rool = 0;
        HttpClient clientD, clientE;
        public MainWindow()
        {
            InitializeComponent();
            #region Show Dep in CB
            clientD = new HttpClient();
            string urlD = @"http://localhost:50918/getlistD";
            clientD.DefaultRequestHeaders.Add("Accept", "application/json");
            List<Department> DeserDep = JsonConvert.DeserializeObject<List<Department>>(clientD.GetStringAsync(urlD).Result);
            foreach (var item in DeserDep)
            {
                WorkerComBox.Items.Add(item.NAMEDep);
            }
            #endregion
        }
        #region AddDep
        /// <summary>
        /// Добавление нововго департаента
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddDEP_Click(object sender, RoutedEventArgs e)
        {
            AddDep AddWinDep = new AddDep();
            AddWinDep.ShowDialog();
        }
        #endregion
        #region AddEmp
        /// <summary>
        /// Добавление новового сотрудника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddEmp_Click(object sender, RoutedEventArgs e)
        {
            AddEmp AddWinEmp = new AddEmp();
            AddWinEmp.ShowDialog();
        }
        #endregion
        #region Загрузка списка сотрудников по департаменту
        /// <summary>
        /// Загрузка данных согласно выбранному департаменту
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WorkerComBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            #region Show Emp by Dep in VL
            //MessageBox.Show(WorkerComBox.Text);
            clientE = new HttpClient();

            string urlE = @"http://localhost:50918/getlistE/" + WorkerComBox.SelectedItem;
            clientE.DefaultRequestHeaders.Add("Accept", "application/json");
            List<Employee> DeserEmp = JsonConvert.DeserializeObject<List<Employee>>(clientD.GetStringAsync(urlE).Result);
            WorkerList.Items.Clear();
            foreach (var item in DeserEmp)
            {
                WorkerList.Items.Add(item.FIO);
            }
            #endregion
        }
        #endregion


    }
}
