﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientLess8
{
    public class Department
    {
        public string NAMEDep { get; set; }
    }
}
