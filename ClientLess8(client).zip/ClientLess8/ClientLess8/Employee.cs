﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientLess8
{
    public class Employee
    {
        public string FIO { get; set; }
        public string DepId { get; set; }
    }
}
