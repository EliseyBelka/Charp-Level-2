﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClientLess8
{
    /// <summary>
    /// Логика взаимодействия для EditDep.xaml
    /// </summary>
    public partial class AddDep : Window
    {
        public AddDep()
        {
            InitializeComponent();
        }

        private void AddButton(object sender, RoutedEventArgs e)
        {

            #region AddDepartment
            HttpClient clientD = new HttpClient();
            string urlD = @"http://localhost:50918/addDep";
            Department Dep = new Department()
            {
                NAMEDep = TBD.Text
            };
            string objD = JsonConvert.SerializeObject(Dep);
            StringContent contentD = new StringContent(objD, Encoding.UTF8, "application/json");
            var resD = clientD.PostAsync(urlD, contentD).Result;
            Console.WriteLine(resD);
            #endregion
        }

        private void cancelButton(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
