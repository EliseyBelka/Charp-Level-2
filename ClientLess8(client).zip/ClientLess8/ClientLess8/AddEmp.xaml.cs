﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClientLess8
{
    /// <summary>
    /// Логика взаимодействия для AddEmp.xaml
    /// </summary>
    public partial class AddEmp : Window
    {
        public AddEmp()
        {
            InitializeComponent();
        }

        private void AddEmp_Click(object sender, RoutedEventArgs e)
        {
            #region AddEmployee
            HttpClient clientE = new HttpClient();
            string urlE = @"http://localhost:50918/addEmp";
            Employee Work = new Employee()
            {
                FIO = TBE.Text,
                DepId = TBEID.Text,
            };
            string objE = JsonConvert.SerializeObject(Work);
            StringContent contentE = new StringContent(objE, Encoding.UTF8, "application/json");
            var resE = clientE.PostAsync(urlE, contentE).Result;
            Console.WriteLine(resE);
            #endregion
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
