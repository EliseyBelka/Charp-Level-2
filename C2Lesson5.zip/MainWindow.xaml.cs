﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace C2Lesson5
{
    public class cWorkers
    {
        public string Employee;
        public string Department;
        public cWorkers(string employee, string department)
        {
            Employee = employee;
            Department = department;
        }
    }

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<cWorkers> workers = new List<cWorkers>();
        public MainWindow()
        {
            InitializeComponent();
            //формирвоание списка сотрудников с категорями
            string[] Dep = new string[] { "Прг", "Бух", "Адм" };
            Random rnd = new Random() { };
            for (int i = 0; i < 25; i++)
            {
                workers.Add(new cWorkers("ЧОС-" + i, Dep[rnd.Next(0, Dep.Length - 1)]));
            }
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            for (int i = 0; i < workers.Count; i++)
            {
                ListView1.Items.Add(workers[i].Employee);
                ListView1.Items.Add(workers[i].Department);

                Console.WriteLine(workers[i].Employee + " " + workers[i].Department);
            }
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}


/*
 https://studassistent.ru/charp/otobrazhenie-kollekcii-v-listview-c
 http://c-sharp.pro/?p=508
 https://ru.stackoverflow.com/questions/766931/%D0%97%D0%B0%D0%BF%D0%BE%D0%BB%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5-listview
*/
