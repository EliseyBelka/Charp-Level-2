﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace C2Lesson5
{
    public class cWorkers
    {
        public string Employee;
        public string Department;
        public cWorkers(string employee, string department)
        {
            Employee = employee;
            Department = department;
        }
    }

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<cWorkers> workers = new List<cWorkers> ();
       
        public MainWindow()
        {
            InitializeComponent();
            //формирвоание списка сотрудников с категорями
            string[] Dep = new string[] { "Прг", "Бух", "Адм" };
            ComboBoxDep.Items.Add("Прг");
            ComboBoxDep.Items.Add("Бух");
            ComboBoxDep.Items.Add("Адм");
            Random rnd = new Random() { };
            for (int i = 0; i < 10; i++)
            {
                workers.Add(new cWorkers("ЧОС-" + i, Dep[rnd.Next(0, Dep.Length - 1)]));
            }
        }
        /// <summary>
        /// Прив выборе формы - активной
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Activated(object sender, EventArgs e)
        {
            ListView1.Items.Clear();
            for (int i = 0; i < workers.Count; i++)
            {
                ListView1.Items.Add(workers[i].Employee+"     "+workers[i].Department);
            }
        }
        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {//Случайно выбранные действия не получается убрать как WF при запуске
        }
        /// <summary>
        /// удаление позиции из списка
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                workers.RemoveAt(ListView1.SelectedIndex);
                ListView1.Items.Clear();
                for (int i = 0; i < workers.Count; i++)
                {
                    ListView1.Items.Add(workers[i].Employee + "     " + workers[i].Department);
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                       
            }
           
        }
        /// <summary>
        /// Вызв окна добавления нововго сотрудника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TBD.Visibility = TBE.Visibility = AddNew.Visibility = Visibility.Visible;
                Add.Visibility = Visibility.Hidden;
            }
            catch (ArgumentOutOfRangeException)
            {

            }
        }
        /// <summary>
        /// Нажатие клавиши Edit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ListView1.SelectedIndex != -1)
                {
                    Edit.Visibility = Visibility.Hidden;
                    ComboBoxDep.Visibility = TBE.Visibility = AddEdit.Visibility = Visibility.Visible;
                    TBE.Text = workers[ListView1.SelectedIndex].Employee;
                    ComboBoxDep.Text = workers[ListView1.SelectedIndex].Department;
                    workers.RemoveAt(ListView1.SelectedIndex);
                } else MessageBox.Show("Не выбран элемент для изменения");
            }
            catch (ArgumentOutOfRangeException)
            {
                       
            }
        }
        /// <summary>
        /// Нажатие клавиши AddEdit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_AddEdit(object sender, RoutedEventArgs e)
        {
            ComboBoxDep.Visibility = TBE.Visibility = AddEdit.Visibility = Visibility.Hidden;
            if (TBE.Text!="" & ComboBoxDep.Text!="") workers.Add(new cWorkers(TBE.Text, ComboBoxDep.Text));
            ListView1.Items.Clear();
            for (int i = 0; i < workers.Count; i++)
            {
                ListView1.Items.Add(workers[i].Employee + "     " + workers[i].Department);
            }
            ComboBoxDep.Text = TBE.Text = "";
             Edit.Visibility = Visibility.Visible;

        }
        /// <summary>
        /// Добавление новой позицци в список
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddNew_Click(object sender, RoutedEventArgs e)
        {
            TBD.Visibility = TBE.Visibility = AddNew.Visibility = Visibility.Hidden;
            if (TBE.Text != "" & TBD.Text != "") workers.Add(new cWorkers(TBE.Text, TBD.Text));
            ListView1.Items.Clear();
            for (int i = 0; i < workers.Count; i++)
            {
                ListView1.Items.Add(workers[i].Employee + "     " + workers[i].Department);
            }
            TBD.Text = TBE.Text = "";
            ComboBoxDep.Items.Add(workers[workers.Count - 1].Department);
            Add.Visibility = Visibility.Visible;
        }
    }
}