﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace С2Lesson8.Models
{
    public class Department
    {
        //public int Id { get; set; }
        public string NAMEDep { get; set; }
    }
}