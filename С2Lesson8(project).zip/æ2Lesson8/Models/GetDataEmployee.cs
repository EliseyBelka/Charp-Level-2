﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using С2Lesson8.Models;

namespace С2Lesson8.Controllers
{
    public class DataEmployee
    { 
        private SqlConnection sqlConnection;
        public DataEmployee()
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;
                                            Initial Catalog=Less7;
                                            Integrated Security=True;";
            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
        }
        #region Employee Comm
        public List<Employee> GetListE()
        {
            List<Employee> list = new List<Employee>();
            string sql = @"SELECT * FROM Employee";
            using (SqlCommand com = new SqlCommand(sql, sqlConnection))
            {
                using (SqlDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(
                            new Employee()
                            {
                                FIO = reader["FIO"].ToString(),
                                DepId = reader["DepId"].ToString(),
                            });
                    }
                }
            }
            return list;
        }
        public List<Employee> GetEmployeeById(string Id)
        {
            List<Employee> list = new List<Employee>();
            string sql = $@"SELECT * FROM Employee WHERE DepId='{Id}'";
            Employee temp = new Employee();
            using (SqlCommand com = new SqlCommand(sql, sqlConnection))
            {
                using (SqlDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //temp = new Employee()
                        //{
                        //    FIO = reader["FIO"].ToString(),
                        //    DepId = reader["DepId"].ToString(),
                        //};
                        list.Add(
                            new Employee()
                            {
                                FIO = reader["FIO"].ToString(),
                                DepId = reader["DepId"].ToString(),
                            });
                    }
                }
            }
            //return temp;
            return list;
        }
        public bool AddEmployee(Employee Worker)
        {
            try
            {
                string sqlAdd = $@" INSERT INTO Employee(FIO, DepId)
                                   VALUES(N'{Worker.FIO}',
                                          N'{Worker.DepId}' ) ";
                using (var com = new SqlCommand(sqlAdd, sqlConnection))
                {
                    com.ExecuteNonQuery();
                }
            }
            catch
            {
                return false;
            }
            return true;
        }
        #endregion
    }
}