﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using С2Lesson8.Models;

namespace С2Lesson8.Controllers
{ 
    public class DataDepartment
{
    private SqlConnection sqlConnection;
    public DataDepartment()
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;
                                            Initial Catalog=Less7;
                                            Integrated Security=True;";
        sqlConnection = new SqlConnection(connectionString);
        sqlConnection.Open();
    }

        #region Department Comm
        public List<Department> GetListD()
        {
            List<Department> list = new List<Department>();
            string sql = @"SELECT * FROM Department";
            using (SqlCommand com = new SqlCommand(sql, sqlConnection))
            {
                using (SqlDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(
                            new Department()
                            {
                                NAMEDep = reader["NAMEDep"].ToString()
                            });
                    }
                }
            }
            return list;
        }
        public Department GetDepartmentById(int Id)
        {
            string sql = $@"SELECT * FROM Department WHERE Id={Id}";
            Department temp = new Department();
            using (SqlCommand com = new SqlCommand(sql, sqlConnection))
            {
                using (SqlDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        temp = new Department()
                        {
                            NAMEDep = reader["NAMEDep"].ToString()
                        };
                    }
                }
            }
            return temp;
        }
        public bool AddDepartment(Department Worker)
        {
            try
            {
                string sqlAdd = $@" INSERT INTO Department(NAMEDep)
                                   VALUES(N'{Worker.NAMEDep}' ) ";
                using (var com = new SqlCommand(sqlAdd, sqlConnection))
                {
                    com.ExecuteNonQuery();
                }
            }
            catch
            {
                return false;
            }
            return true;
        }
        #endregion
    }
}