﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using С2Lesson8.Models;

namespace С2Lesson8.Controllers
{
    public class EmployeeController : ApiController
    {
        private DataEmployee data = new DataEmployee();


        [Route("getlistE")]
        public List<Employee> Get() => data.GetListE();

        [Route("getlistE/{id}")]
        public List<Employee> Get(string id) => data.GetEmployeeById(id);

        [Route("addEmp")]
        public HttpResponseMessage Post([FromBody]Employee value)
        {
            if (data.AddEmployee(value))
                return Request.CreateResponse(HttpStatusCode.Created);
            else return Request.CreateResponse(HttpStatusCode.BadRequest);
        }

    }
}