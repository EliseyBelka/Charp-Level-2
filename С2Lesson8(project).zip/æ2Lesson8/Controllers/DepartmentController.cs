﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using С2Lesson8.Models;

namespace С2Lesson8.Controllers
{
    public class DepartmentController : ApiController
    {
        private DataDepartment data = new DataDepartment();


        [Route("getlistD")]
        public List<Department> Get() => data.GetListD();

        [Route("getlistD/{id}")]
        public Department Get(int id) => data.GetDepartmentById(id);

        [Route("addDep")]
        public HttpResponseMessage Post([FromBody]Department value)
        {
            if (data.AddDepartment(value))
                return Request.CreateResponse(HttpStatusCode.Created);
            else return Request.CreateResponse(HttpStatusCode.BadRequest);
        }

    }
}